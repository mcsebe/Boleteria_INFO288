
import os
from controller import *

if __name__ == '__main__':
    run_app()
